package com.dksharma.project;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class Attendance extends Activity {
CheckBox sa;
RadioGroup atype;
StringBuffer responseText;
 MyCustomAdapter dataAdapter = null;
 ArrayList<Student> StudentList = new ArrayList<Student>();
 ProgressBar pb;

 @Override
 public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  setContentView(R.layout.attendance);
  atype= (RadioGroup)findViewById(R.id.attype);
pb = (ProgressBar)findViewById(R.id.apb);
  displayListView();

  ImageView save = (ImageView)findViewById(R.id.save_attend);
  save.setOnClickListener(new OnClickListener() {
	
	@Override
	public void onClick(View v) {
		checkButtonClick();
		 Bundle data = getIntent().getExtras();
		String branch = data.getString("Branch");
		String semester = data.getString("Semester");
		SharedPreferences sp = getSharedPreferences("mypref", MODE_PRIVATE);
		String faculty=sp.getString("id", null);
		String subject = data.getString("Subject");
		new submitattendance().execute("http://testing.dipaksharma.com/save_attendance.php",responseText.toString(),semester.substring(0,1),faculty,subject,branch);
		
	}
});

 }

 private void displayListView() {
	 Bundle data = getIntent().getExtras();
	 String br = data.getString("Branch");
	 String sem = data.getString("Semester");
     //Toast.makeText(getApplicationContext(), sem.substring(0, 3), Toast.LENGTH_SHORT).show();
	 new studenlist().execute("http://testing.dipaksharma.com/student_list.php?branch="+br+"&semester="+sem.substring(0, 1));
  
 }
private class studenlist extends AsyncTask<String, Void, Void>{
	StringBuilder s = null;JSONArray n=null;
	@Override
	protected Void doInBackground(String... params) {
		// TODO Auto-generated method stub
		 
		   RetrieveJSON jsondata = new RetrieveJSON();
		   s = jsondata.getData(params[0]);
		   
		return null;
	}

	@Override
	protected void onPostExecute(Void result) {
		super.onPostExecute(result);
		pb.setVisibility(View.GONE);
		atype.setVisibility(View.VISIBLE);
		//Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
		try {
			JSONObject jobj = new JSONObject(s.toString());
			n = jobj.getJSONArray("students");
			for(int i=0;i<n.length();i++){
				JSONObject ob = n.getJSONObject(i);
				StudentList.add(new Student(ob.getString("roll"), ob.getString("name"), false));
			}
			
		} catch (JSONException e) {
			e.printStackTrace();
		}
		dataAdapter = new MyCustomAdapter(getApplicationContext(),
			    R.layout.student_info, StudentList);
			  ListView listView = (ListView) findViewById(R.id.attendance_list);
			  // Assign adapter to ListView
			  listView.setAdapter(dataAdapter);


			  listView.setOnItemClickListener(new OnItemClickListener() {
			   public void onItemClick(AdapterView<?> parent, View view,
			     int position, long id) {
			    // When clicked, show a toast with the TextView text
			    
			    /*Toast.makeText(getApplicationContext(),
			      "Clicked on Row: " + Student.getName(), 
			      Toast.LENGTH_LONG).show();*/
		       CheckBox cb = (CheckBox)view.findViewById(R.id.checkBox1);
		       Student student = (Student)cb.getTag();
		       if(!cb.isChecked()){
                 student.setSelected(true);
		         cb.setChecked(true);
		       }
		       else
		    	   {
		    	   student.setSelected(false);
		           cb.setChecked(false);
		    	   }
			   }
			  });
				

	}

	
}
 private class MyCustomAdapter extends ArrayAdapter<Student> {

  private ArrayList<Student> StudentList;

  public MyCustomAdapter(Context context, int textViewResourceId, 
    ArrayList<Student> StudentList) {
   super(context, textViewResourceId, StudentList);
   this.StudentList = new ArrayList<Student>();
   this.StudentList.addAll(StudentList);
  }

  private class ViewHolder {
   TextView roll;
   CheckBox name;
  }

  @Override
  public View getView(int position, View convertView, ViewGroup parent) {

   ViewHolder holder = null;
   //Log.v("ConvertView", String.valueOf(position));

   if (convertView == null) {
   LayoutInflater vi = (LayoutInflater)getSystemService(
     Context.LAYOUT_INFLATER_SERVICE);
   convertView = vi.inflate(R.layout.student_info, null);

   holder = new ViewHolder();
   holder.roll = (TextView) convertView.findViewById(R.id.roll);
   holder.name = (CheckBox) convertView.findViewById(R.id.checkBox1);
   convertView.setTag(holder);

    holder.name.setOnClickListener( new View.OnClickListener() {  
     public void onClick(View v) {  
      CheckBox cb = (CheckBox) v ;  
      Student student = (Student) cb.getTag();  
      /*Toast.makeText(getApplicationContext(),
       "Clicked on Checkbox: " + cb.getText() +
       " is " + cb.isChecked(), 
       Toast.LENGTH_LONG).show();*/
      student.setSelected(cb.isChecked());
      //checkButtonClick();
     }  
    });  
   } 
   else {
    holder = (ViewHolder) convertView.getTag();
   }

   Student student = StudentList.get(position);
   holder.roll.setText(" (" +  student.getRoll() + ")");
   holder.name.setText(student.getName());
   holder.name.setChecked(student.isSelected());
   holder.name.setTag(student);

   return convertView;

  }

 }

 private void checkButtonClick() {


     responseText = new StringBuffer();
    ArrayList<Student> StudentList = dataAdapter.StudentList;
    for(int i=0;i<StudentList.size();i++){
     Student student = StudentList.get(i);
     if(student.isSelected()){
      responseText.append(student.getRoll()+",");
     }
    }
    

    /*Toast.makeText(getApplicationContext(),
      responseText, Toast.LENGTH_LONG).show();*/
     

 }
private class submitattendance extends AsyncTask<String, Void, Void>{
   String response1 = "";
	@Override
	protected Void doInBackground(String... params) {
          HttpClient httpclient = new DefaultHttpClient();
          HttpPost httppost = new HttpPost(params[0]);
          List<NameValuePair> stu = new ArrayList<NameValuePair>(1);
          stu.add(new BasicNameValuePair("students", params[1]));
          stu.add(new BasicNameValuePair("semester", params[2]));
          stu.add(new BasicNameValuePair("faculty", params[3]));
          stu.add(new BasicNameValuePair("subject", params[4]));
          stu.add(new BasicNameValuePair("branch", params[5]));
          try
          {
        	  httppost.setEntity(new UrlEncodedFormEntity(stu));
              ResponseHandler<String> responsehandler = new BasicResponseHandler();
              response1=httpclient.execute(httppost,responsehandler);
          }
          catch(Exception e){
        	  
          }
		return null;
	}
	@Override
	protected void onPostExecute(Void result) {
		super.onPostExecute(result);
		Toast.makeText(getApplicationContext(),response1, Toast.LENGTH_SHORT).show();
	}
	
}
}