package com.dksharma.project;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Admin_home extends Activity{
  SharedPreferences sp;
  private DrawerLayout drlayout;
  private ListView dlist;
  private ActionBarDrawerToggle dtoggle;
@Override
protected void onCreate(Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
	setContentView(R.layout.admin_main);
	sp = getSharedPreferences("mypref",MODE_PRIVATE);
	drlayout = (DrawerLayout)findViewById(R.id.admin_drawer_layout);
	dlist = (ListView)findViewById(R.id.admin_left_drawer);
	ArrayAdapter<String> adap = new ArrayAdapter<String>(this, R.layout.list_item);
	//adap.add("Home");
	getFragmentManager().beginTransaction().add(R.id.admin_content_frame, new Add_admin(getApplicationContext())).commit();
	adap.add("Add Admin");
	//adap.add("Update Profile");
	adap.add("Add Faculty");
	adap.add("Add Subject");
	adap.add("Add Class");
	adap.add("Manage Subject");
	adap.add("Manage Class");
	adap.add("Manage Faculty");
	adap.add("Logout");
	dlist.setAdapter(adap);
	dlist.setOnItemClickListener(new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			drlayout.closeDrawers();
			switch(position){
			case 0:
				getFragmentManager().beginTransaction().replace(R.id.admin_content_frame, new Add_admin(getApplicationContext())).commit();
				break;
			case 1:
				getFragmentManager().beginTransaction().replace(R.id.admin_content_frame, new add_faculty(getApplicationContext())).commit();
				break;
			case 2:
				getFragmentManager().beginTransaction().replace(R.id.admin_content_frame, new add_subject(getApplicationContext())).commit();
				break;
			case 3:
				getFragmentManager().beginTransaction().replace(R.id.admin_content_frame, new add_class(getApplicationContext())).commit();
			    break;
			case 4:
				getFragmentManager().beginTransaction().replace(R.id.admin_content_frame, new Manage_subject(getApplicationContext())).commit();
			    break;
			case 5:
				getFragmentManager().beginTransaction().replace(R.id.admin_content_frame, new Manage_class(getApplicationContext())).commit();
			    break;
			case 6:
				getFragmentManager().beginTransaction().replace(R.id.admin_content_frame, new Manage_Faculty(getApplicationContext())).commit();
				break;
			case 7:
				SharedPreferences.Editor spedit = sp.edit();
				spedit.putString("login_status", "false");
				spedit.putString("id", null);
				spedit.commit();
				Intent i = new Intent(getApplicationContext(),loginactivity.class);
				startActivity(i);
				finish();
			}
	
		}
	});
	dtoggle = new ActionBarDrawerToggle(
            this,                 
            drlayout,         
            R.drawable.ic_drawer,  
            R.string.app_name,  
            R.string.app_name  
            ) {

    	public void onDrawerClosed(View view) {
    		super.onDrawerClosed(view);
            getActionBar().setTitle("Open");
           
        }

        public void onDrawerOpened(View drawerView) {
        	super.onDrawerOpened(drawerView);
            getActionBar().setTitle("Close");
           
        }
    };
	drlayout.setDrawerListener(dtoggle);
    getActionBar().setDisplayHomeAsUpEnabled(true);
   getActionBar().setHomeButtonEnabled(true);
   

}

@Override
protected void onPostCreate(Bundle savedInstanceState) {
    super.onPostCreate(savedInstanceState);

    dtoggle.syncState();
}

@Override
public void onConfigurationChanged(Configuration newConfig) {
    super.onConfigurationChanged(newConfig);
    dtoggle.onConfigurationChanged(newConfig);
}

@Override
public boolean onOptionsItemSelected(MenuItem item) {

    if (dtoggle.onOptionsItemSelected(item)) {
    	
      return true;
    }
   

    return super.onOptionsItemSelected(item);
}
}
