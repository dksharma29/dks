package com.dksharma.project;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class profile extends Activity{

	ImageView profile;Context context;Bitmap bmp;
	TextView sname,sbranch;
	ProgressBar pb1,pb2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.profile);
		sname= (TextView)findViewById(R.id.student_name);
		sbranch = (TextView)findViewById(R.id.student_branch);
		profile =(ImageView)findViewById(R.id.profile_image);
		pb1 = (ProgressBar)findViewById(R.id.pbas);
		pb2 = (ProgressBar)findViewById(R.id.progressBar2);
		new DownloadImageTask().execute("http://www.bcetnss.com/dipak.jpg");
		new getProfiledata().execute("http://testing.dipaksharma.com/student_list.php");
		profile.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
				//startActivityForResult(i, 100);
				
				
			}
			
		});
	}
	 @Override
		protected void onActivityResult(int requestCode, int resultCode, Intent data) {
			// TODO Auto-generated method stub
			super.onActivityResult(requestCode, resultCode, data);
			
			if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
				Uri selectedImage = data.getData();
			    String[] filePathColumn = { MediaStore.Images.Media.DATA };

			    Cursor cursor = getContentResolver().query(selectedImage,filePathColumn, null, null, null);
			    cursor.moveToFirst();

			    int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
			    String picturePath = cursor.getString(columnIndex);
			    cursor.close();
			    Bitmap b1=BitmapFactory.decodeFile(picturePath);
			    //saveToInternalSorage(b1);
			    Bitmap b2=ThumbnailUtils.extractThumbnail(b1,120, 120);
			    profile.setImageBitmap(b2);
		        //Now you can do whatever you want with your inpustream, save it as file, upload to a server, decode a bitmap...
		    }
		}
	 private String saveToInternalSorage(Bitmap bitmapImage){
	        ContextWrapper cw = new ContextWrapper(getApplicationContext());
	         // path to /data/data/yourapp/app_data/imageDir
	        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
	        // Create imageDir
	        File mypath=new File(directory,"profile.jpg");

	        FileOutputStream fos = null;
	        try {           

	            fos = new FileOutputStream(mypath);

	       // Use the compress method on the BitMap object to write image to the OutputStream
	            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
	            fos.close();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return directory.getAbsolutePath();
	    }
	 private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
		    protected Bitmap doInBackground(String... urls) {
		        String urldisplay = urls[0];
		        Bitmap mIcon11 = null;
		        try {
		            InputStream in = new java.net.URL(urldisplay).openStream();
		            mIcon11 = BitmapFactory.decodeStream(in);
		        } catch (Exception e) {
		            Log.e("Error", e.getMessage());
		            e.printStackTrace();
		        }
		        return mIcon11;
		    }

		    protected void onPostExecute(Bitmap result) {
		    	Bitmap bm1=ThumbnailUtils.extractThumbnail(result,120, 120);
		        profile.setImageBitmap(bm1);
		        pb2.setVisibility(View.INVISIBLE);
		    }

}
	 private class getProfiledata extends AsyncTask<String, Void, Void>{
        StringBuilder sb = new StringBuilder();
		@Override
		protected Void doInBackground(String... params) {
			RetrieveJSON rjs = new RetrieveJSON();
			sb = rjs.getData(params[0]);
			return null;
		}
		@Override
		protected void onPostExecute(Void result) {
			
			super.onPostExecute(result);
			JSONArray name = null ;String n="";String m = "";
			try {
				JSONObject jobj = new JSONObject(sb.toString());
				name = jobj.getJSONArray("students");
				 for (int i = 0; i < name.length(); i++) {
                     JSONObject c = name.getJSONObject(i);
                     n = c.getString("name");
                     m = c.getString("roll");
                     
				 }
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			sname.setText(n);
			sbranch.setText(m);
			pb1.setVisibility(View.INVISIBLE);
			Toast.makeText(getApplicationContext(), n, Toast.LENGTH_SHORT).show();
			
		}
		 
	 }
	 }
