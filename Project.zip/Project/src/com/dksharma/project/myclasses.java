package com.dksharma.project;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.DefaultClientConnection;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Fragment;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

public class myclasses extends Fragment{
	Context context;SharedPreferences sp;String id;String response;
	ListView lv;ProgressBar mcpb;ArrayAdapter<String> adap;
	public myclasses(Context context){
		this.context = context;
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
			View view = inflater.inflate(R.layout.myclasses, container, false);
			lv = (ListView)view.findViewById(R.id.myclasslv);
			mcpb = (ProgressBar)view.findViewById(R.id.mcpb);
			sp = context.getSharedPreferences("mypref", Context.MODE_PRIVATE);
			adap = new ArrayAdapter<String>(context, R.layout.list_item);
			new getmyclass().execute("http://testing.dipaksharma.com/myclass.php");
			return view;
	}
  private class getmyclass extends AsyncTask<String, Void, Void>{

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
		}

	@Override
	protected Void doInBackground(String... params) {
		id = sp.getString("id", null);
		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost(params[0]);
		List<NameValuePair> nvpl = new ArrayList<NameValuePair>(1);
		nvpl.add(new BasicNameValuePair("id", id));
		try{
			httppost.setEntity(new UrlEncodedFormEntity(nvpl));
			ResponseHandler<String> responsehandler = new BasicResponseHandler();
			response = httpclient.execute(httppost,responsehandler);
		}
		catch(Exception e){
			
		}
		return null;
	}

	@Override
	protected void onPostExecute(Void result) {
		try {
			JSONObject jobj = new JSONObject(response);
			JSONArray jarray = jobj.getJSONArray("classes");
			for(int i=0; i<jarray.length();i++){
				JSONObject ob = jarray.getJSONObject(i);
				String id = ob.getString("id");
				String subject = ob.getString("subject_id");
				String faculty = ob.getString("faculty");
				adap.add(subject+": "+faculty);
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		lv.setAdapter(adap);
		mcpb.setVisibility(View.GONE);
		super.onPostExecute(result);
	}
	  
  }
}
