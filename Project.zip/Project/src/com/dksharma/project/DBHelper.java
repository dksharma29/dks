package com.dksharma.project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
	public static final String DATABASE_NAME = "Project.db";
	public static final String TABLE1_NAME = "faculty";
	public static final String TABLE2_NAME = "class";
	public static final String TABLE3_NAME = "subject";

	DBHelper(Context context){
		super(context,DATABASE_NAME,null,1);
		} 
	public void onCreate(SQLiteDatabase db) {
		
		db.execSQL("create table faculty(id integer primary key,name text,department text);");
		db.execSQL("create table "+TABLE3_NAME+"(id integer primary key,subject_code text,subject_name text);");
		db.execSQL("create table "+TABLE2_NAME+"(id integer primary key,branch text,semester text,subject text);");
	}
	
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		db.execSQL("Drop table if exists "+TABLE1_NAME);
		/*db.execSQL("Drop table if exists"+TABLE2_NAME);
		db.execSQL("Drop table if exists"+TABLE3_NAME);*/
		onCreate(db);
	}
	public boolean insertData(String name,String phone,String email){
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues cv = new ContentValues();
		cv.put("name", name);
		cv.put("department", phone);
		//cv.put("email",email);
		db.insert("faculty", null, cv);
		return true;
		
	}
	public boolean deleteData(int id){
		SQLiteDatabase db =this.getWritableDatabase();
		db.execSQL("Delete from "+TABLE1_NAME+" where id="+id);
		return true;
	}
	public Cursor getdata(int id){
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor res = db.rawQuery("select * from mytab", null);
		
		return res;
	}
	public int numberOfRows(){
		SQLiteDatabase db = this.getReadableDatabase();
		int numRows = (int) DatabaseUtils.queryNumEntries(db, TABLE1_NAME);
		return numRows;
	}
	
	}
