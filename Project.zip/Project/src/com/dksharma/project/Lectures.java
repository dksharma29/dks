package com.dksharma.project;

public class Lectures {

	String branch;
	String semester;
	String subject;
	public Lectures(String branch,String semester,String subject){
		this.branch=branch;
		this.semester=semester;
		this.subject=subject;
	}
	public String getBranch(){
		return branch; 
	}
	public void setBranch(String branch){
		this.branch = branch;
	}
	public String getSemester(){
		return semester;
	}
	public void setSemester(String semester){
		this.semester = semester;
	}
	public String getSubject(){
		return subject;
	}
	public void setSubject(String subject){
		this.subject=subject;
	}
}
