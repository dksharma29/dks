package com.dksharma.project;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;

public class Manage_Faculty extends Fragment{
	Context context;
	ListView flist;
	StringBuilder s;String[] username;
	ProgressBar facpb;
	ArrayAdapter<String> adap;
	public Manage_Faculty(Context context){
		this.context = context;
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
       View view = inflater.inflate(R.layout.manage_faculty, container,false);
       flist = (ListView)view.findViewById(R.id.flist);
       facpb = (ProgressBar)view.findViewById(R.id.facpb);
       username = new String[25];
       adap = new ArrayAdapter<String>(context, R.layout.list_item);
       
       new getfaculty().execute("http://testing.dipaksharma.com/getdetails.php");
       return view;
	}
	private class getfaculty extends AsyncTask<String, Void, Void>{
		
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
		}
		@Override
		protected Void doInBackground(String... params) {
			RetrieveJSON rjson = new RetrieveJSON();
			s=rjson.getData(params[0]);
			
			return null;
		}



		@Override
		protected void onPostExecute(Void result) {
			try {
				JSONObject jobj= new JSONObject(s.toString());
				JSONArray jarray = jobj.getJSONArray("faculty");
				for(int i=0;i<jarray.length();i++){
					JSONObject jar1 = jarray.getJSONObject(i);
					String faculty_name = jar1.getString("name");
					String dept = jar1.getString("department");
					username[i] = jar1.getString("username");
					adap.add(faculty_name+"("+dept+")");
					
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			facpb.setVisibility(View.GONE);
			flist.setAdapter(adap);
			flist.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					Intent i = new Intent(context, Update_faculty.class);
					Bundle data = new Bundle();
					data.putString("faculty", parent.getItemAtPosition(position).toString());
					data.putString("username", username[position]);
					i.putExtras(data);
					startActivity(i);
				}
			});
			super.onPostExecute(result);
		}
		
	}

}
