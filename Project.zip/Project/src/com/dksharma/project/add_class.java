package com.dksharma.project;


import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Fragment;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

public class add_class extends Fragment{
   Spinner branch,semester,subject,faculty;
   String response;
   ProgressBar addcpb;
   Button addc;Context context;ArrayAdapter<String> faculty_adapter;
   ArrayAdapter<String> subject_adapter ;
   StringBuilder sb;
   String response1,response2;
   InputStream is;
   public add_class(Context context){
	   this.context = context;
   }
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
         View view=inflater.inflate(R.layout.add_class,container,false);
         addcpb = (ProgressBar)view.findViewById(R.id.addcpb);
         branch = (Spinner)view.findViewById(R.id.class_branch);
         semester = (Spinner)view.findViewById(R.id.class_semester);
         subject = (Spinner)view.findViewById(R.id.class_subject);
         faculty = (Spinner)view.findViewById(R.id.class_faculty);
         addc = (Button)view.findViewById(R.id.add_class);
         ArrayAdapter<String> branch_adapter = new ArrayAdapter<String>(context, R.layout.spinner_item);
         ArrayAdapter<String> semester_adapter = new ArrayAdapter<String>(context, R.layout.spinner_item);
         subject_adapter = new ArrayAdapter<String>(context, R.layout.spinner_item);
         faculty_adapter = new ArrayAdapter<String>(context, R.layout.spinner_item);
         semester_adapter.add("1st");
         semester_adapter.add("2nd");
         semester_adapter.add("3rd");
         semester_adapter.add("4th");
         semester_adapter.add("5th");
         semester_adapter.add("6th");
         semester_adapter.add("7th");
         semester_adapter.add("8th");
         semester.setAdapter(semester_adapter);
         branch_adapter.add("IT");
         branch_adapter.add("CSE");
         branch_adapter.add("ECE");
         branch_adapter.add("CHE");
         branch_adapter.add("ME");
         branch_adapter.add("BT");
         branch.setAdapter(branch_adapter);
			new getinfo().execute("http://testing.dipaksharma.com/getdetails.php");
         addc.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String sem = semester.getSelectedItem().toString().substring(0, 1);
				String fac = faculty.getSelectedItem().toString();
				String sub = subject.getSelectedItem().toString();
				String br = branch.getSelectedItem().toString();
                new lectureadd().execute("http://testing.dipaksharma.com/add_lecture.php",sem,fac,sub,br);

			}
		});
         return view;
	}
	private class lectureadd extends AsyncTask<String, Void, Void>{

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			addcpb.setVisibility(View.VISIBLE);
		}

		@Override
		protected Void doInBackground(String... params) {
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(params[0]);
			List<NameValuePair> lec = new ArrayList<NameValuePair>(4);
			lec.add(new BasicNameValuePair("semester",params[1]));
			lec.add(new BasicNameValuePair("faculty",params[2]));
			lec.add(new BasicNameValuePair("subject",params[3]));
			lec.add(new BasicNameValuePair("branch",params[4]));
			try{
				httppost.setEntity(new UrlEncodedFormEntity(lec));
			}
			catch(Exception e)
			{
				
			}
			try{
				ResponseHandler<String> responsehandler = new BasicResponseHandler();
				response = httpclient.execute(httppost,responsehandler);
			}
			catch(Exception e){
				
			}
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			Toast.makeText(context, response, Toast.LENGTH_SHORT).show();
			addcpb.setVisibility(View.INVISIBLE);
			
		}

		
		
	}
	private class getinfo extends AsyncTask<String, Void, Void>{

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			addcpb.setVisibility(View.VISIBLE);
			addc.setVisibility(View.GONE);
		}

		@Override
		protected Void doInBackground(String... params) {
			RetrieveJSON json = new RetrieveJSON();
			sb = json.getData(params[0]);
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
            try{
            	JSONObject jobj = new JSONObject(sb.toString());
            	JSONArray ja1 = jobj.getJSONArray("faculty");
            	JSONArray ja2 = jobj.getJSONArray("subjects");
            	for(int i=0;i<ja1.length();i++){
            		JSONObject ja1o = ja1.getJSONObject(i);
            		faculty_adapter.add(ja1o.getString("name")+"("+ja1o.getString("department")+")");
            	}
            	faculty.setAdapter(faculty_adapter);
            	for(int i=0;i<ja2.length();i++){
            		JSONObject ja2o = ja2.getJSONObject(i);
            		subject_adapter.add(ja2o.getString("subject_code"));
            	}
            	subject.setAdapter(subject_adapter);
            }
            catch(Exception e){
            	
            }
			super.onPostExecute(result);
			addcpb.setVisibility(View.INVISIBLE);
			addc.setVisibility(View.VISIBLE);
		}
		
	}
}
