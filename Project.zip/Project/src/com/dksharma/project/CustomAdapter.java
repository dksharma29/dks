package com.dksharma.project;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class CustomAdapter extends ArrayAdapter<String>{
	public CustomAdapter(Context context,String[] str) {
		// TODO Auto-generated constructor stub
		super(context,R.layout.list_item,str);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		LayoutInflater inflater = LayoutInflater.from(getContext());
		View customView = inflater.inflate(R.layout.list_item, parent,false);
		String item = getItem(position);
		TextView tv = (TextView)customView.findViewById(R.id.litem);
		tv.setText(item);
		return customView;
	}

}
