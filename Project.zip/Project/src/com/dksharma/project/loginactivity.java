package com.dksharma.project;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class loginactivity extends Activity{
	Button login;
	Button register;
	EditText username;
	EditText password;
	CheckBox rem;
	Spinner type;
	Context context;
	SharedPreferences sp;
	int i=0;
	public void onCreate(Bundle data){
		super.onCreate(data);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.login);
		
		username = (EditText)findViewById(R.id.user);
		password = (EditText)findViewById(R.id.pwd);
		rem = (CheckBox)findViewById(R.id.rem);
		login=(Button)findViewById(R.id.login);
		register = (Button)findViewById(R.id.signup);
		type = (Spinner)findViewById(R.id.type);
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.spinner_item);
		adapter.add("Student");
		adapter.add("Faculty");
		adapter.add("Admin");
		type.setAdapter(adapter);
		sp = getSharedPreferences("mypref", MODE_PRIVATE);
		String lstatus = sp.getString("login_status", null);
		//Toast.makeText(getApplicationContext(), lstatus+sp.getString("id", null), Toast.LENGTH_SHORT).show();
		String uname = sp.getString("Username", null);
		String pass = sp.getString("Password", null);
		String ltype = sp.getString("type", null);
		if(lstatus.equals("true")){
			if(ltype.equals("Student")){
			Intent i =new Intent(getApplicationContext(), Student_Home.class);
			startActivity(i);
			finish();
			}
			else if(ltype.equals("Faculty")){
				Intent i =new Intent(getApplicationContext(), Faculty_main.class);
				startActivity(i);
				finish();
			}
			else if(ltype.equals("Admin")){
				Intent i =new Intent(getApplicationContext(), Admin_home.class);
				startActivity(i);
				finish();
			}
		}
		username.setText(uname);
		password.setText(pass);
		final CheckConnection in = new CheckConnection();
		login.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String user = username.getText().toString();
				String pass = password.getText().toString();
				if(!in.isInternet(getApplicationContext()))
					Toast.makeText(getApplicationContext(), "No Internet", Toast.LENGTH_SHORT).show();
				else
				{
					
				if(user.equals(""))
				Toast.makeText(getApplicationContext(),"Please enter username", Toast.LENGTH_SHORT).show();
				else if(pass.equals(""))
				Toast.makeText(getApplicationContext(),"Please enter password", Toast.LENGTH_SHORT).show();
				else
				{
					
						new loginact1().execute("http://testing.dipaksharma.com/login.php");
						
				}
					//Toast.makeText(getApplicationContext(),type.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
				if(rem.isChecked()){
					//SharedPreferences sp = getSharedPreferences("mypref", MODE_PRIVATE);
					SharedPreferences.Editor pedit = sp.edit();
					pedit.putString("Username", user);
					pedit.putString("Password", pass);
					pedit.commit();
					
				}
				}
				
				//else
					//Toast.makeText(getApplicationContext(), "Not Checked", Toast.LENGTH_SHORT).show();
			}
		});
		register.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i = new Intent(getApplicationContext(), register.class);
				startActivity(i);
				
			}
		});
	}
@Override
public void onBackPressed() {

	
if(i==0){
	Toast.makeText(this, "Press again to exit", Toast.LENGTH_SHORT).show();i++;
}
else
	finish();
		}
public class loginact1 extends AsyncTask<String, Void, Void> {
 
	private ProgressDialog Dialog = new ProgressDialog(loginactivity.this);
	String response;
	final HttpClient client = new DefaultHttpClient();
	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();

		Dialog.setMessage("Logging...");
		Dialog.setCancelable(false);
		Dialog.show();
		
		//Dialog.setCancelable(false);
		
		
	}
	@Override
	protected Void doInBackground(String... url) {
		// TODO Auto-generated method stub
		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost(url[0]);
		List<NameValuePair> nameValuePair = new ArrayList<NameValuePair>(2);
        nameValuePair.add(new BasicNameValuePair("username", username.getText().toString()));
        nameValuePair.add(new BasicNameValuePair("password", password.getText().toString()));
        nameValuePair.add(new BasicNameValuePair("type", type.getSelectedItem().toString()));
        //Encoding POST data
        try {
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePair));
        } catch (UnsupportedEncodingException e) {
            // log exception
            e.printStackTrace();
        }
 
        //making POST request.
        try {
        	ResponseHandler<String> responseHandler = new BasicResponseHandler();
             response = httpclient.execute(httppost,responseHandler);
            // write response to log
           // Log.d("Http Post Response:", response.toString());
        } catch (ClientProtocolException e) {
            // Log exception
            e.printStackTrace();
        } catch (IOException e) {
            // Log exception
            e.printStackTrace();
        }
 
    

		return null;
	}
	@Override
	protected void onPostExecute(Void result) {
		super.onPostExecute(result);
		try {
			JSONObject jobj = new JSONObject(response.toString());
			JSONArray jarray= jobj.getJSONArray("login");
			JSONObject ob = jarray.getJSONObject(0);
			String type = ob.getString("type");
			//Toast.makeText(getApplicationContext(), type, Toast.LENGTH_SHORT).show();
			if(type.equals("Admin")){
				JSONArray jarray3 = jobj.getJSONArray("admin_info");
				JSONObject ob3 = jarray3.getJSONObject(0);
				String id = ob3.getString("id");
				SharedPreferences.Editor spedit = sp.edit();
				spedit.putString("login_status", "true");
				spedit.putString("type", "Admin");
				spedit.putString("id", id);
				spedit.commit();
				Intent i =new Intent(getApplicationContext(), Admin_home.class);
				startActivity(i);
				finish();
			}
			else if(type.equals("Faculty")){
				JSONArray jarray2 = jobj.getJSONArray("faculty_info");
				JSONObject ob2 = jarray2.getJSONObject(0);
				String id = ob2.getString("id");
				SharedPreferences.Editor spedit = sp.edit();
				spedit.putString("login_status", "true");
				spedit.putString("type", "Faculty");
				spedit.putString("id", id);
				spedit.commit();
				Intent i =new Intent(getApplicationContext(), Faculty_main.class);
				startActivity(i);
				finish();
			}
			else if(type.equals("Student")){
				JSONArray jarray1 = jobj.getJSONArray("student_info");
				JSONObject ob1 = jarray1.getJSONObject(0);
				String id = ob1.getString("id");
				SharedPreferences.Editor spedit = sp.edit();
				spedit.putString("login_status", "true");
				spedit.putString("type", "Student");
				spedit.putString("id", id);
				spedit.commit();
				Intent i =new Intent(getApplicationContext(), Student_Home.class);
				startActivity(i);
				finish();
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
		Dialog.dismiss();
	}
}
}
