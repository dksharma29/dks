package com.dksharma.project;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;

public class Manage_subject extends Fragment{
    ListView sublist;
    ProgressBar supb;
    StringBuilder sb;Context context;
    ArrayAdapter<String> adap;
    public Manage_subject(Context context) {
         this.context = context;
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
       
		View view = inflater.inflate(R.layout.manage_subject, container,false);
		sublist = (ListView)view.findViewById(R.id.msublist);
		supb = (ProgressBar)view.findViewById(R.id.upsbar);
		adap = new ArrayAdapter<String>(context, R.layout.list_item);
		new getsubject().execute("http://testing.dipaksharma.com/getdetails.php");
		return view;
		
	}
	private class getsubject extends AsyncTask<String, Void, Void>{


		@Override
		protected void onPreExecute() {

			super.onPreExecute();
		}
		@Override
		protected Void doInBackground(String... params) {
         RetrieveJSON jsn = new RetrieveJSON();
         sb=jsn.getData(params[0]);
			return null;
		}


		@Override
		protected void onPostExecute(Void result) {
           try {
			JSONObject jobj = new JSONObject(sb.toString());
			JSONArray jarray = jobj.getJSONArray("subjects");
			for(int i=0;i<jarray.length();i++){
				JSONObject ob = jarray.getJSONObject(i);
				String sub_name = ob.getString("subject_name");
				String sub_code = ob.getString("subject_code");
				
				adap.add(sub_code+":"+sub_name);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
           sublist.setAdapter(adap);
           supb.setVisibility(View.GONE);
           sublist.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				Intent i =new Intent(context, Update_subject.class);
                    Bundle data = new Bundle();
                    data.putString("subject", parent.getItemAtPosition(position).toString());
                    i.putExtras(data);
                    startActivity(i);
                    
				
			}
		});
			super.onPostExecute(result);
		}
		
	}

}
