package com.dksharma.project;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class take_attendance extends Fragment{
    ListView classlist;
    Context context;
    Lectures lecture;
    ProgressBar pb;
    SharedPreferences sp;
    ArrayList<Lectures> leclist = new ArrayList<Lectures>();
	public take_attendance(Context context){
		this.context = context;
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		
		View view = inflater.inflate(R.layout.take_attendance, container,false);
		sp = context.getSharedPreferences("mypref",0);
		String id = sp.getString("id",null);
		pb = (ProgressBar)view.findViewById(R.id.attpb);
		classlist = (ListView)view.findViewById(R.id.class_list);
		new getlectures().execute("http://testing.dipaksharma.com/get_classes.php?fid="+id);
		/*leclist.add(new Lectures("IT", "4th", "Cloud Computing"));
		leclist.add(new Lectures("CSE", "3rd", "Network Programming"));
		leclist.add(new Lectures("BT", "2nd", "Chemistry"));
		leclist.add(new Lectures("CHE", "1st", "Chemical Reaction"));
		
		CustomAdapter2 cadp2 = new CustomAdapter2(context, R.layout.lecture_list,leclist);
		classlist.setAdapter(cadp2);
		*/
		return view;
           
	}
    private class getlectures extends AsyncTask<String, Void, Void>{
        StringBuilder sb;
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
		}
		@Override
		protected Void doInBackground(String... params) {
			RetrieveJSON obj = new RetrieveJSON();
			sb=obj.getData(params[0]);
			return null;
		}



		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			try {
				JSONObject jobj = new JSONObject(sb.toString());
				JSONArray jarray = jobj.getJSONArray("classes");
				for(int i=0;i<jarray.length();i++){
					JSONObject ob = jarray.getJSONObject(i);
					leclist.add(new Lectures(ob.getString("branch"), ob.getString("semester"), ob.getString("subject")));
					CustomAdapter2 cadap = new CustomAdapter2(context, R.layout.lecture_list, leclist);
					classlist.setAdapter(cadap);
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			pb.setVisibility(View.GONE);
			classlist.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					TextView sub = (TextView)view.findViewById(R.id.subj_code);
					TextView br = (TextView)view.findViewById(R.id.lec_brnch);
					TextView sem = (TextView)view.findViewById(R.id.lec_sem);
					Bundle data = new Bundle();
					data.putString("Branch", br.getText().toString());
					data.putString("Semester", sem.getText().toString());
					data.putString("Subject", sub.getText().toString());
					Intent i = new Intent(context,Attendance.class);
					i.putExtras(data);
					startActivity(i);
					//Toast.makeText(context, br.getText().toString(), Toast.LENGTH_SHORT).show();
					
				}
			});
		}
    	
    }
}
