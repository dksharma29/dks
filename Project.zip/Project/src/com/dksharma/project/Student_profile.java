package com.dksharma.project;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

public class Student_profile extends Fragment{
	Context context;
      public Student_profile(Context context) {
		// TODO Auto-generated constructor stub
    	  this.context = context;
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.profile, container,false);
		ImageView profile_image = (ImageView)view.findViewById(R.id.profile_image);
		profile_image.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(context, "Hello", Toast.LENGTH_SHORT).show();
			}
		});
		return view;
	}

}
