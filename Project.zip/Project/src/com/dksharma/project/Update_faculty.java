package com.dksharma.project;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

public class Update_faculty extends Activity{
    Spinner fspn;String username;
    TextView fname,user;String faculty,fac_name,fdept;int pos;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.update_faculty);
		Bundle data = getIntent().getExtras();
		fspn = (Spinner)findViewById(R.id.fcu_dept);
		fname = (TextView)findViewById(R.id.fcu_name);
		user = (TextView)findViewById(R.id.fcu_user);
		faculty = data.getString("faculty");
		username = data.getString("username");
		fdept = faculty.substring(faculty.indexOf("(")+1, faculty.indexOf(")"));
		fac_name = faculty.substring(0, faculty.indexOf("("));
		fname.setText(fac_name);
		user.setText(username);
		ArrayAdapter<String> adap = new ArrayAdapter<String>(getApplicationContext(), R.layout.spinner_item);
		adap.add("IT");
		adap.add("CSE");
		adap.add("CHE");
		adap.add("ME");
		adap.add("ECE");
		adap.add("BT");
		fspn.setAdapter(adap);
		for(int i=0;i<adap.getCount();i++){
			if(fspn.getItemAtPosition(i).equals(fdept)){
			pos=i;break;
		}
		}
			fspn.setSelection(pos);
	}
	
}
