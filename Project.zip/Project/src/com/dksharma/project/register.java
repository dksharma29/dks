package com.dksharma.project;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ActionBar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class register extends Activity {
	EditText email,name;
	EditText roll;
	EditText pass;
	EditText cpass;
	String brnch,sem,mail,roll_no,pswd,cpswd,sname;
	Spinner branch,semester;
    Button reg;
    Button sgnin;
    SharedPreferences sp;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		//requestWindowFeature(Window.FEATURE_NO_TITLE);
		ActionBar act = getActionBar();
		act.setDisplayHomeAsUpEnabled(true);
		act.setTitle("Register");
		setContentView(R.layout.register);
		sp = getSharedPreferences("mypref", MODE_PRIVATE);
		name = (EditText)findViewById(R.id.name);
		email = (EditText)findViewById(R.id.email);
		roll = (EditText)findViewById(R.id.roll);
		branch = (Spinner)findViewById(R.id.branch);
		semester = (Spinner)findViewById(R.id.semester);
		pass = (EditText)findViewById(R.id.pswd);
		cpass = (EditText)findViewById(R.id.cpswd);
		reg = (Button)findViewById(R.id.register);
		sgnin = (Button)findViewById(R.id.login);
		ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this,
		        R.array.branch, android.R.layout.simple_list_item_1);
		ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,
		        R.array.semester, android.R.layout.simple_list_item_1);
		adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		branch.setAdapter(adapter1);
		semester.setAdapter(adapter2);
		branch.setSelection(0);
		reg.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				int f;
				// TODO Auto-generated method stub
				    if(email.getText().toString().equals("")
				    		|| name.getText().toString().equals("") 
				    		|| pass.getText().toString().equals("") || roll.getText().toString().equals("")
				    		|| cpass.getText().toString().equals(""))
				    	f=0;
				    	
				    else if(!cpass.getText().toString().equals(pass.getText().toString()))
				    	f=1;
				    else f=2;
				    if(f==0)
				    Toast.makeText(getApplicationContext(), "All fields are required", Toast.LENGTH_SHORT).show();
				    else if(f==1)
				    	Toast.makeText(getApplicationContext(), "Password doesn't match", Toast.LENGTH_SHORT).show();
					//Toast.makeText(getApplicationContext(),pass.getText()+"  "+cpass.getText(), Toast.LENGTH_SHORT).show();
				
				sname = name.getText().toString();
				mail = email.getText().toString();
				roll_no = roll.getText().toString();
				pswd = pass.getText().toString();
				cpswd = cpass.getText().toString();
				brnch = branch.getSelectedItem().toString();
				sem = semester.getSelectedItem().toString();
				CheckConnection in = new CheckConnection();
				if(in.isInternet(getApplicationContext()) && f==2)
				new doregistration().execute("http://testing.dipaksharma.com/register.php",sname,mail,roll_no,brnch,sem,pswd,cpswd);
				else
					
				Toast.makeText(getApplicationContext(), "No Internet", Toast.LENGTH_SHORT).show();
				/*Toast.makeText(getApplicationContext(), sem, Toast.LENGTH_SHORT).show();*/
			}
		});
		sgnin.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Intent i1 = new Intent(getApplicationContext(),loginactivity.class);
				startActivity(i1);
				finish();
			}
		});
	}
   public class doregistration extends AsyncTask<String, Void, Void>{
		String response;
	   private ProgressDialog Dialog = new ProgressDialog(register.this);
	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub

		super.onPreExecute();
		Dialog.setMessage("Please wait..");
		Dialog.show();
	}

	@Override
	protected Void doInBackground(String... params) {
		// TODO Auto-generated method stub

		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost(params[0]);
		List<NameValuePair> nvpair = new ArrayList<NameValuePair>(7);
				nvpair.add(new BasicNameValuePair("name",params[1]));
				nvpair.add(new BasicNameValuePair("email", params[2]));
				nvpair.add(new BasicNameValuePair("roll",params[3]));
				nvpair.add(new BasicNameValuePair("branch", params[4]));
				nvpair.add(new BasicNameValuePair("semester",params[5]));
				nvpair.add(new BasicNameValuePair("pass", params[6]));
				nvpair.add(new BasicNameValuePair("cpass",params[7]));
		try{
			httppost.setEntity(new UrlEncodedFormEntity(nvpair));
		}
		catch(Exception e){
			Toast.makeText(getApplicationContext(), "Error Occured",Toast.LENGTH_SHORT).show();
		}
		try {
        	ResponseHandler<String> responseHandler = new BasicResponseHandler();
             response = httpclient.execute(httppost,responseHandler);
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
		return null;
	}
	@Override
	protected void onPostExecute(Void result) {
		String status="" ;
		super.onPostExecute(result);
		Dialog.dismiss();
		try {
			JSONObject jobj = new JSONObject(response);
			JSONArray jarray = jobj.getJSONArray("registration");
			JSONObject ob = jarray.getJSONObject(0);
			status = ob.getString("status");
			if(status.equals("success")){
				JSONArray arr1 = jobj.getJSONArray("student_info");
				JSONObject ob1 = arr1.getJSONObject(0);
				String id = ob1.getString("id");
				SharedPreferences.Editor spedit = sp.edit();
				spedit.putString("login_status", "true");
				spedit.putString("type", "Student");
				spedit.putString("id", id);
				spedit.commit();
				Intent i =new Intent(getApplicationContext(), Student_Home.class);
				startActivity(i);
				finish();
			}
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			Toast.makeText(getApplicationContext(),status,Toast.LENGTH_SHORT).show();
		
	}
   }
}
