package com.dksharma.project;

import java.util.ArrayList;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class dbactivity extends Activity{
	
	EditText name;
	EditText phone;
	EditText email;
	EditText get;
	Button getb;
	Button save;
	String n,p,mail;
	DBHelper db;
	ListView dbv;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dblayout);
		name =(EditText)findViewById(R.id.name);
		phone = (EditText)findViewById(R.id.phone);
		email = (EditText)findViewById(R.id.email);
		save = (Button)findViewById(R.id.save);
		get = (EditText)findViewById(R.id.get);
		getb = (Button)findViewById(R.id.getb);
		db = new DBHelper(this);
		dbv = (ListView)findViewById(R.id.dbname);
		save.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				n = name.getText().toString();
				p = phone.getText().toString();
				mail = email.getText().toString();
				db.insertData(n,p,mail);
				
				Toast.makeText(getApplicationContext(), name.getText().toString(), Toast.LENGTH_SHORT).show();
			}
		});
		getb.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				//String[] a ={"A","B","C"}; 
				ArrayAdapter<String> name = new ArrayAdapter<String>(getApplicationContext(), R.layout.list_item);
				// TODO Auto-generated method stub
				/*int n = Integer.parseInt(get.getText().toString());
				db.deleteData(n);*/
				Cursor c =db.getdata(1);
				String s="";
				c.moveToFirst();
				do{				
				name.add(c.getString(1));
				}while(c.moveToNext());
				//Toast.makeText(getApplicationContext(), name.getItem(1), Toast.LENGTH_SHORT).show();
				dbv.setAdapter(name);
				dbv.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> parent, View view,
							int position, long id) {
						// TODO Auto-generated method stub
						dbv.getChildAt(position).setBackgroundColor(Color.MAGENTA);
						Toast.makeText(getApplicationContext(), ""+position, Toast.LENGTH_SHORT).show();
					}
					
				});
			}
		});
		}
	

}
