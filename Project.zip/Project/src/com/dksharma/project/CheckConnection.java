package com.dksharma.project;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class CheckConnection {
	ConnectivityManager cm ;
	NetworkInfo[] ni;
	public boolean isInternet(Context context){
		cm = (ConnectivityManager)context.getSystemService(context.CONNECTIVITY_SERVICE);
		ni = cm.getAllNetworkInfo();
		if(ni != null)
		{
			for(int i=0;i<ni.length;i++)
			{
				if(ni[i].getState() == NetworkInfo.State.CONNECTED)
					return true;
			}
		}
		return false;
	}
}
