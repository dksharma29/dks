package com.dksharma.project;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Fragment;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

public class add_faculty extends Fragment{
	Context context;
	EditText fname,fuser,fpass,fcpass;
	Spinner fdept;Button fadd;
	ProgressBar apb;
	public add_faculty(Context context){
		this.context = context;
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.add_faculty, container,false);
		fname = (EditText)view.findViewById(R.id.faculty_name);
		fdept = (Spinner)view.findViewById(R.id.faculty_dept);
		fpass = (EditText)view.findViewById(R.id.faculty_pass);
		fcpass = (EditText)view.findViewById(R.id.faculty_cpass);
		fuser = (EditText)view.findViewById(R.id.faculty_username);
		fadd = (Button)view.findViewById(R.id.add_faculty);
		apb = (ProgressBar)view.findViewById(R.id.addfpb);
		ArrayAdapter<String> adap = new ArrayAdapter<String>(context, R.layout.spinner_item);
		adap.add("IT");
		adap.add("CSE");
		adap.add("CHE");
		adap.add("ME");
		adap.add("ECE");
		adap.add("BT");
		fdept.setAdapter(adap);
		fadd.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				//Toast.makeText(context, "ADDED", Toast.LENGTH_SHORT).show();
				new add_fac().execute("http://testing.dipaksharma.com/add_faculty.php");
				apb.setVisibility(View.VISIBLE);
				
			}
		});
		return view;
	}
	
  private class add_fac extends AsyncTask<String, Void, Void>{
      //private ProgressDialog pd = new ProgressDialog(context);
      String response;
	@Override
	protected void onPreExecute() {

		super.onPreExecute();
		fadd.setClickable(false);
		
	}


	@Override
	protected Void doInBackground(String... params) {
        HttpClient httpclient = new DefaultHttpClient();
        HttpPost httppost = new HttpPost(params[0]);
        List<NameValuePair> fl = new ArrayList<NameValuePair>(4);
        fl.add(new BasicNameValuePair("fuser", fuser.getText().toString()));
        fl.add(new BasicNameValuePair("fname", fname.getText().toString()));
        fl.add(new BasicNameValuePair("fpass", fpass.getText().toString()));
        fl.add(new BasicNameValuePair("fcpass", fcpass.getText().toString()));
        fl.add(new BasicNameValuePair("fdept", fdept.getSelectedItem().toString()));
		
		try{
			httppost.setEntity(new UrlEncodedFormEntity(fl));
		}
		catch(Exception e){
			Toast.makeText(context, "Something wrong",Toast.LENGTH_SHORT).show();
		}
		try{
			ResponseHandler<String> responsehandler = new BasicResponseHandler();
			response = httpclient.execute(httppost,responsehandler);
		}
		catch(Exception e){
			
		}
		return null;
	}
	@Override
	protected void onPostExecute(Void result) {

		super.onPostExecute(result);
		Toast.makeText(context, response, Toast.LENGTH_SHORT).show();
		apb.setVisibility(View.INVISIBLE);
		fadd.setClickable(true);
	}

	  
  }
}
