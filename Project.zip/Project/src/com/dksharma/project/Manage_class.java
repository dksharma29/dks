package com.dksharma.project;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Fragment;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

public class Manage_class extends Fragment{
    ProgressBar mcpb;
    ListView class_list;
    StringBuilder sb;
    ArrayAdapter<String> adap;
    Context context;
    public Manage_class(Context context) {
      this.context = context;
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
       View view = inflater.inflate(R.layout.manage_class, container,false);
       mcpb  = (ProgressBar)view.findViewById(R.id.mcpb);
       class_list =(ListView)view.findViewById(R.id.mclist);
       adap = new ArrayAdapter<String>(context, R.layout.list_item);
       new getclass().execute("http://testing.dipaksharma.com/getdetails.php");
       return view;
	}
   private class getclass extends AsyncTask<String, Void, Void>{

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
		}

	@Override
	protected Void doInBackground(String... params) {
		RetrieveJSON rjson = new RetrieveJSON();
		sb = rjson.getData(params[0]);
		return null;
	}


	@Override
	protected void onPostExecute(Void result) {
		try {
			JSONObject jobj = new JSONObject(sb.toString());
			JSONArray jarray = jobj.getJSONArray("class");
			for(int i=0;i<jarray.length();i++){
				JSONObject ob = jarray.getJSONObject(i);
				String branch = ob.getString("branch");
				String semester = ob.getString("semester");
				String subject = ob.getString("subject");
				adap.add(subject+" Semester"+semester+" "+branch);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		class_list.setAdapter(adap);
		mcpb.setVisibility(View.GONE);
		super.onPostExecute(result);
	}
	   
   }
}
