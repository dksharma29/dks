package com.dksharma.project;


import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class Student_Home extends Activity{
  SharedPreferences sp;
  private DrawerLayout drlayout;
  private ListView dlist;
  private ActionBarDrawerToggle dtoggle;
@Override
protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.user_main);
	sp = getSharedPreferences("mypref",MODE_PRIVATE);
	drlayout = (DrawerLayout)findViewById(R.id.student_drawer_layout);
	getFragmentManager().beginTransaction().add(R.id.student_content_frame, new myclasses(getApplicationContext())).commit();
	dlist = (ListView)findViewById(R.id.student_left_drawer);
	ArrayAdapter<String> adap = new ArrayAdapter<String>(this, R.layout.list_item);
	ActionBar ab =getActionBar();
	ab.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#ffbf80")));
	//adap.add("Home");
	//adap.add("My Profile");
	adap.add("My Classes");
	//adap.add("Attendance");
	adap.add("Logout");
	dlist.setAdapter(adap);
	dlist.setBackgroundResource(R.color.BlanchedAlmond);
	dlist.setOnItemClickListener(new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
		switch(position){
		case 0:
			getFragmentManager().beginTransaction().replace(R.id.student_content_frame, new myclasses(getApplicationContext())).commit();
			//Toast.makeText(getApplicationContext(), sp.getString("id",null), Toast.LENGTH_SHORT).show();
			break;
		case 1:
			SharedPreferences.Editor spedit = sp.edit();
			spedit.putString("login_status", "false");
			spedit.putString("id", null);
			spedit.commit();
			Intent i = new Intent(getApplicationContext(), loginactivity.class);
			startActivity(i);
			finish();
		}
			drlayout.closeDrawers();
		}
	});
	dtoggle = new ActionBarDrawerToggle(
            this,                 
            drlayout,         
            R.drawable.ic_drawer,  
            R.string.app_name,  
            R.string.app_name  
            ) {

    	public void onDrawerClosed(View view) {
    		super.onDrawerClosed(view);
            getActionBar().setTitle("Open");
           
        }

        public void onDrawerOpened(View drawerView) {
        	super.onDrawerOpened(drawerView);
            getActionBar().setTitle("Close");
           
        }
    };
	drlayout.setDrawerListener(dtoggle);
    getActionBar().setDisplayHomeAsUpEnabled(true);
   getActionBar().setHomeButtonEnabled(true);
   

}

@Override
protected void onPostCreate(Bundle savedInstanceState) {
    super.onPostCreate(savedInstanceState);

    dtoggle.syncState();
}

@Override
public void onConfigurationChanged(Configuration newConfig) {
    super.onConfigurationChanged(newConfig);
    dtoggle.onConfigurationChanged(newConfig);
}

@Override
public boolean onOptionsItemSelected(MenuItem item) {

    if (dtoggle.onOptionsItemSelected(item)) {
    	
      return true;
    }
   

    return super.onOptionsItemSelected(item);
}
}
