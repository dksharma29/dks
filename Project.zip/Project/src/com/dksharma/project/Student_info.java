package com.dksharma.project;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class Student_info extends Activity{
String sb;String roll;int flag=0;LinearLayout ll;ProgressBar spb;
TextView sname,sroll,ssem,sbranch,semail;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.student_details);
		spb=(ProgressBar)findViewById(R.id.sigpb);
		ll=(LinearLayout)findViewById(R.id.silayout);
		sname=(TextView)findViewById(R.id.siname);
		sroll=(TextView)findViewById(R.id.siroll);
		ssem=(TextView)findViewById(R.id.sisem);
		sbranch=(TextView)findViewById(R.id.sibranch);
		semail=(TextView)findViewById(R.id.siemail);
		Bundle data = getIntent().getExtras();
		roll = data.getString("roll");
		new getsinfo().execute("http://testing.dipaksharma.com/student_info.php");
	}

	private class getsinfo extends AsyncTask<String, Void, Void>{


			@Override
			protected void onPreExecute() {
				super.onPreExecute();
			}

			@Override
			protected Void doInBackground(String... params) {
					HttpClient httpclient = new DefaultHttpClient();
					HttpPost httppost = new HttpPost(params[0]);
					List<NameValuePair> lnp = new ArrayList<NameValuePair>(1);
					lnp.add(new BasicNameValuePair("roll",roll ));
					try{
						httppost.setEntity(new UrlEncodedFormEntity(lnp));
						ResponseHandler<String> handler = new BasicResponseHandler();
						sb=httpclient.execute(httppost,handler);
					}
					catch(Exception e){
					}
				return null;
			}

			@Override
			protected void onPostExecute(Void result) {
	            try{
	            	JSONObject jobj = new JSONObject(sb.toString());
	            	JSONArray ja1 = jobj.getJSONArray("student");
                         
	            		JSONObject ja1o = ja1.getJSONObject(0);
	            		String name = ja1o.getString("name").toString();
	            		String roll = ja1o.getString("roll_number").toString();
	            		String branch = ja1o.getString("branch").toString();
	            		String semester = ja1o.getString("semester").toString();
	            		String email = ja1o.getString("email").toString();
	            		
	            		sname.setText(name);
	            		sroll.setText(roll);
	            		sbranch.setText(branch);
	            		ssem.setText(semester);
	            		semail.setText(email);
                         spb.setVisibility(View.GONE);
                         ll.setVisibility(View.VISIBLE);
	            		
	            	
	            }
	            catch(Exception e){
	            	
	            }
				super.onPostExecute(result);
				
			}
			
		}
	}
