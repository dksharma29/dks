package com.dksharma.project;

import java.util.ArrayList;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class CustomAdapter2 extends ArrayAdapter<Lectures>{
    
	TextView lec,branch,semester;
	private ArrayList<Lectures> lecture_list;
	Context context;
	public CustomAdapter2(Context context,
			int textViewResourceId,ArrayList<Lectures> lecture_list) {
		super(context,textViewResourceId, lecture_list);
		this.lecture_list = new ArrayList<Lectures>();
		this.lecture_list.addAll(lecture_list);
		this.context = context;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		LayoutInflater li = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View view = li.inflate(R.layout.lecture_list, null);
		lec = (TextView)view.findViewById(R.id.subj_code);
		branch=(TextView)view.findViewById(R.id.lec_brnch);
		semester = (TextView)view.findViewById(R.id.lec_sem);
		Lectures lect  = lecture_list.get(position);
		lec.setText(lect.getSubject());
		semester.setText(lect.getSemester()+" Semester");
		branch.setText(lect.getBranch());
		return view;
	}
	

}
