package com.dksharma.project;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

public class Update_subject extends Activity{
   EditText scode,sname;ProgressBar uspb;Button update;Bundle data;
   ProgressBar uspd;String response;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.update_subject);
		scode = (EditText)findViewById(R.id.usub_code);
		sname = (EditText)findViewById(R.id.usub_name);
		update = (Button)findViewById(R.id.upd_sub);
		uspd = (ProgressBar)findViewById(R.id.uspb);
		data = getIntent().getExtras();
		String subject = data.getString("subject");
		String sub_name = subject.substring(subject.indexOf(":")+1,subject.length());
		String sub_code = subject.substring(0,subject.indexOf(":"));
		scode.setText(sub_code);
		scode.setEnabled(false);
		sname.setText(sub_name);
		update.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				new updatesub().execute("http://testing.dipaksharma.com/update_subject.php");
			}
		});
	}
	private class updatesub extends AsyncTask<String, Void, Void>{

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			uspd.setVisibility(View.VISIBLE);
		}

		@Override
		protected Void doInBackground(String... params) {
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(params[0]);
			List<NameValuePair> nvp = new ArrayList<NameValuePair>(2);
			nvp.add(new BasicNameValuePair("sub_name", sname.getText().toString()));
			nvp.add(new BasicNameValuePair("sub_code", scode.getText().toString()));
			try{
				httppost.setEntity(new UrlEncodedFormEntity(nvp));
				ResponseHandler<String> responsehandler = new BasicResponseHandler();
				response = httpclient.execute(httppost,responsehandler);
			}
			catch(Exception e){
				
			}
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();	
			uspd.setVisibility(View.INVISIBLE);
		}
		
	}

}
