package com.dksharma.project;

import java.util.ArrayList;

import android.app.ActionBar;
import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class Home extends Activity{
	private String[] menulist;
    private DrawerLayout dlayout;
    private ListView mDrawerList;
    private ActionBarDrawerToggle mDrawerToggle;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.user_main);
	        dlayout = (DrawerLayout) findViewById(R.id.student_drawer_layout);
	        mDrawerList = (ListView) findViewById(R.id.student_left_drawer);
	      
            ArrayAdapter<String> arad = new ArrayAdapter<String>(this,
	                R.layout.list_item);
	        menulist = new String[10];
            /*for(int i=0;i<10;i++){
            	menulist[i]=""+i;
            }*/
            arad.add("Home");
            arad.add("Profile");
            
	       // mDrawerList.setAdapter(new CustomAdapter(this, menulist));
	      mDrawerList.setAdapter(arad);
	      // mDrawerList.addHeaderView(getLayoutInflater().inflate(R.layout.head, null));
	      mDrawerList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				dlayout.closeDrawers();
				if(position==1){
					getFragmentManager().beginTransaction().add(R.id.student_content_frame,new Student_profile(getApplicationContext())).commit();
				}
				// TODO Auto-generated method stub
				
			}
		});
	
	        mDrawerToggle = new ActionBarDrawerToggle(
	                this,                 
	                dlayout,         
	                R.drawable.ic_drawer,  
	                R.string.app_name,  
	                R.string.app_name  
	                ) {

	        	public void onDrawerClosed(View view) {
	        		super.onDrawerClosed(view);
	                getActionBar().setTitle("Open");
	               
	            }

	            public void onDrawerOpened(View drawerView) {
	            	super.onDrawerOpened(drawerView);
	                getActionBar().setTitle("Close");
	               
	            }
	        };


	        // Set the drawer toggle as the DrawerListener
	        dlayout.setDrawerListener(mDrawerToggle);
	        getActionBar().setDisplayHomeAsUpEnabled(true);
	       getActionBar().setHomeButtonEnabled(true);

	}
	@Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Pass the event to ActionBarDrawerToggle, if it returns
        // true, then it has handled the app icon touch event
        if (mDrawerToggle.onOptionsItemSelected(item)) {
        	
          return true;
        }
        Toast.makeText(getApplicationContext(), item.toString(), Toast.LENGTH_SHORT).show();
        // Handle your other action bar items...

        return super.onOptionsItemSelected(item);
    }
    

}
