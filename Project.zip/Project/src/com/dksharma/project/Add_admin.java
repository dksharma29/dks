package com.dksharma.project;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Fragment;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

public class Add_admin extends Fragment{
    EditText user,pass,cpass;
    Context context;
    Button addadm;String username,password,cpassword;
    ProgressBar addadmpb;
   public Add_admin(Context context) {
		this.context = context;
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
           View view = inflater.inflate(R.layout.add_admin, container,false);
           user = (EditText)view.findViewById(R.id.adm_user);
           pass = (EditText)view.findViewById(R.id.adm_pass);
           cpass = (EditText)view.findViewById(R.id.adm_cpass);
           addadm = (Button)view.findViewById(R.id.add_adm);
           addadmpb = (ProgressBar)view.findViewById(R.id.addadmpb);
           addadm.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				username = user.getText().toString();
		           password = pass.getText().toString();
		           cpassword = cpass.getText().toString();
		           if(!(password.equals(cpassword))){
		        	   Toast.makeText(context, "Password do not match", Toast.LENGTH_SHORT).show();
		           }
		           else if(username.equals("")||password.equals("")||cpassword.equals("")){
		        	   Toast.makeText(context, "Enter details", Toast.LENGTH_SHORT).show();
		           }
		           else
		           {		   			
		        	   new add_admin().execute("http://testing.dipaksharma.com/add_admin.php");
		           }
			}
		});
           
           return view;
	}
	private class add_admin extends AsyncTask<String, Void, Void>{
		String response;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			addadmpb.setVisibility(View.VISIBLE);
		}
		@Override
		protected Void doInBackground(String... params) {
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(params[0]);
			List<NameValuePair> adl = new ArrayList<NameValuePair>();
			adl.add(new BasicNameValuePair("user", username));
			adl.add(new BasicNameValuePair("pass", password));
			adl.add(new BasicNameValuePair("cpass", cpassword));
			try {
				httppost.setEntity(new UrlEncodedFormEntity(adl));
				ResponseHandler<String> handler = new BasicResponseHandler();
				response = httpclient.execute(httppost,handler);
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			return null;
		}


		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			addadmpb.setVisibility(View.INVISIBLE);
			Toast.makeText(context, response, Toast.LENGTH_SHORT).show();
		}
		
	}

}
