package com.dksharma.project;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Fragment;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

public class add_subject extends Fragment{
Context context;
EditText subname,subcode;
Button addsub;ProgressBar pbas;
public add_subject(Context context) {
	this.context = context;
}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.add_subject,container, false);
		subname = (EditText)view.findViewById(R.id.sub_name);
		subcode = (EditText)view.findViewById(R.id.sub_code);
		addsub = (Button)view.findViewById(R.id.add_sub);
		pbas = (ProgressBar)view.findViewById(R.id.pbas);
		addsub.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				new addsubject().execute("http://testing.dipaksharma.com/add_subject.php");
				
				
			}
		});
		return view;
	}
private class addsubject extends AsyncTask<String, Void, Void>
{
	String response;
	@Override
	protected void onPreExecute() {

		super.onPreExecute();
		pbas.setVisibility(View.VISIBLE);
		
	}
	@Override
	protected Void doInBackground(String... params) {
		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost(params[0]);
		List<NameValuePair> sbl = new ArrayList<NameValuePair>(2);
		sbl.add(new BasicNameValuePair("sub_name", subname.getText().toString()));
		sbl.add(new BasicNameValuePair("sub_code", subcode.getText().toString()));
		try{
			httppost.setEntity(new UrlEncodedFormEntity(sbl));
		}
		catch(Exception e){
			
		}
		try{
			ResponseHandler<String> responsehandler = new BasicResponseHandler();
			response = httpclient.execute(httppost,responsehandler);
		}
		catch(Exception e){
			
		}
		return null;
	}



	@Override
	protected void onPostExecute(Void result) {

		super.onPostExecute(result);
		Toast.makeText(context, response, Toast.LENGTH_SHORT).show();
		pbas.setVisibility(View.INVISIBLE);
	}
	
}
}
